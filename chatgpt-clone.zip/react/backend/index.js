const { Configuration, OpenAIApi } = require('openai');
const express = require('express');
const cors = require('cors');

const configuration = new Configuration({
  apiKey: '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',
});

const openai = new OpenAIApi(configuration);

const app = express();
const port = 3080;

app.use(express.json());
app.use(cors()); // Add cors middleware to allow cross-origin requests
app.get('/', (req, res) => {
  res.send('Hello World!')
});

// testing...
function generatePrompt(animal) {
  const capitalizedAnimal = animal[0].toUpperCase() + animal.slice(1).toLowerCase();
  return `Suggest three names for an animal that is a superhero.

Animal: Cat
Names: Captain Sharpclaw, Agent Fluffball, The Incredible Feline
Animal: Dog
Names: Ruff the Protector, Wonder Canine, Sir Barks-a-Lot
Animal: ${capitalizedAnimal}
Names:`;
}
console.log(generatePrompt('lion'))



app.post('/api/completion', async (req, res) => {

  try { //kindly check fiverr
    const { prompt } = req.body;
    //   const response = await openai.createCompletion({
    //     model: 'text-davinci-003',
    //     prompt: 'Say this is a test',
    //     max_tokens: 7,
    //     temperature: 0
    // })
    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: `${prompt}`,
      temperature: 0.6,
      max_tokens: 200,  //response answer length
    });
    console.log(response.data.choices)
    // console.log(response.data.choices[0].text);
    res.json({
      data: response.data.choices[0].text,
    });
  } catch (error) {
    // if (error.response && error.response.status === 429 && retryCount < maxRetries) {
    //   retryCount++;
    //   const nextRetryDelay = initialRetryDelay * Math.pow(2, retryCount);
    //   console.log(`Rate limited. Retrying in ${nextRetryDelay}ms`);
    //   setTimeout(() => callOpenAI(), nextRetryDelay);
    // } else {
    //   res.status(500).json({ error: 'Error calling OpenAI API' });
    // }
    console.error('Error completing message:', error);
    console.log(error.message)
    res.status(500).json({ error: 'Failed to get response from GPT-3.' });

  }
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});

